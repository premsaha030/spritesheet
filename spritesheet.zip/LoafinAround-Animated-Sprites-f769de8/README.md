# Animated Sprite Tutorial
Tutorial Project to Use Sprite Sheets in Godot

Link for the Sprite Sheets used in the tutorial : https://arks.itch.io/dino-characters

Make sure to Like, Comment, and Subscribe!
